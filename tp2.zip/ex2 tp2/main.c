#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    double x;
    double r;
    printf("donner un reel");
    scanf("%lf",&x);
    if (x<0)
        r=x*(-1) ;
    else r=x;


    printf("%lf",r);
    return 0;
}

