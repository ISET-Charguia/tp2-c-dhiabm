#include <stdio.h>
#include <stdlib.h>

int main()
{
  int a,b,x;
  printf("taper a et b");
  scanf("%d%d",&a,&b);
  x=(-b)/a;
  printf("le resultat est %d",x);
    return 0;
}
