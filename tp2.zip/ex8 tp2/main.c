#include <stdio.h>
#include <stdlib.h>

int main(void) {
	int a;
	double m;
	printf("taper le nombre d’années de dépôt et la montant déposé ");
	scanf("%d %lf",&a,&m);
	if(a > 5)
		printf("taux=0.095");
	else if((a> 3)&(a<=5))
		printf("taux=0.085");
	else if((a> 1)&(a<=3))
		printf("taux=0.065");
	else if(a <= 1)
		printf("taux=0.058");

}
