#include <stdio.h>
#include <stdlib.h>

int main()
{
  int a ;
  printf("taper l'anne");
  scanf("%d",&a);
  if (a%400==0 || (a%4==0 && a%100!=0))
  printf("année est bissextile");

  else printf("année n'est pas bissextile");

    return 0;
}
