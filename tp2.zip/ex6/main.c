#include <stdio.h>
#include <stdlib.h>

int main()
{
    double a,b,c,max,min;
    printf("donner le 3 reels");
    scanf("%lf%lf%lf",&a,&c,&b);

    if((a>b)&&(a>c))
        max=a;
    else if((b>a)&&(b>c))
        max=b;
    else
        max=c;
    if((a<b)||(a<c))
        min=a;
    else if
    ((b<a)||(b<c))
        min=b;
    else
        min=c;

    printf("min%lf max %lf",min,max);


    return 0;
}
