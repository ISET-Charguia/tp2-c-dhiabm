#include <stdio.h>
#include <stdlib.h>

int main()
{
char cr;
printf("taper un car");
scanf("%c",&cr);
if((cr>='0')&&(cr<='9')) printf("chiffre");
else
if((cr>='a')&&(cr<='z')) printf("lettre min");
else
if ((cr >='A')&&(cr <='Z')) printf("lettre max");
else printf("autre");
return 0;
}
