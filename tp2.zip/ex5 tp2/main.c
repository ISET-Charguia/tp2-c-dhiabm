#include <stdio.h>
#include <stdlib.h>

int main()
{
int x,e,d,c;
printf("donner un entier de 3 chiffres");
scanf("%d",&x);
c=x/100;
d=x/10%10;
e=x%10;
printf("%d %d %d",c,d,e);



    return 0;
}
